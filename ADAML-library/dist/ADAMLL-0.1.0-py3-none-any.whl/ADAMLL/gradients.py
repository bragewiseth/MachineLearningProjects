import jax.numpy as np
import jax
from .util import forward, MSE
from .activations import sigmoid





def backprop_one_hidden( X,t, params, activations):
    a0, a1 = activations
    output_error = (a1 - t)
    hidden_error =  output_error @ params.w1.T * a0 * (1 - a0) 

    gw0 = X.T @ hidden_error
    gb0 = np.sum(hidden_error, axis=0)
    gw1 = a0.T @ output_error
    gb1 = np.sum(output_error, axis=0)

    return [{'w': gw0, 'b': gb0}, {'w': gw1, 'b': gb1}]



def backprop_one_hidden_auto( X,t, params, activations , loss=MSE ):
    a0, a1 = activations
    dloss = jax.grad(loss)(a1, t)
    output_error = (a1 - t)
    hidden_error =  output_error @ params.w1.T * jax.grad(sigmoid) (a0)

    gw0 = X.T @ hidden_error
    gb0 = np.sum(hidden_error, axis=0)
    gw1 = a0.T @ output_error * dloss
    gb1 = np.sum(output_error, axis=0)

    return [{'w': gw0, 'b': gb0}, {'w': gw1, 'b': gb1}]




def backward_propagate(network, error, final_activations):
    for i in reversed(range(len(network))):
        layer = network[i]
        delta = error * sigmoid(final_activations[i])
        error = delta.dot(layer['w'].T)
        layer['delta'] = delta
    return network




def single_layer_gradients(X, t, params, activation=sigmoid, loss=MSE):
    w = params[0]['w']
    b = params[0]['b']
    y = np.dot(X , w) + b
    wgrad = (2/X.shape[0]) * np.dot(X.T , (y - t))
    bgrad = 2/X.shape[0] * np.sum(y - t)
    return [{'w': wgrad, 'b': bgrad}]




def build_backprop(activation=sigmoid, loss=MSE, func=backprop_one_hidden_auto):
    def gradient_func(X, t, params):
        return func(X, t, params, activation, loss)
    return gradient_func

